#include <stdio.h>
#include <stdlib.h>

int main()
{
	int* data = malloc(sizeof(int) * 100); // allocate block array space of 100 ints
	
	free(data);
	
	
	printf("%d\n", data[99]);
	
	int* funnyPointerInMiddleOfDataArray = &data[49];
	
	free(data[49]);
	
	
	free(funnyPointerInMiddleOfDataArray); // passing a funny value to free.	
	
	return 0;
}
