#include <stdio.h>
#include <stdlib.h>

int main()
{
	int* ptr = NULL;
	printf("Deferenced int pointer set to NULL is equal to %d\n", *ptr);
	
	return 0;
}
