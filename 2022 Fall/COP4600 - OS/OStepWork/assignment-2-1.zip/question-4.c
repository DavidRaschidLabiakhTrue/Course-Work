#include <stdio.h>
#include <stdlib.h>

int main()
{
	int* array = malloc(sizeof(int) * 5); // block pointed towards space of 5 ints allocated.
	
	return 0;
}
