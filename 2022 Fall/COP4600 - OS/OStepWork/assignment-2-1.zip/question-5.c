#include <stdio.h>
#include <stdlib.h>

int main()
{
	int* data = malloc(sizeof(int) * 100); // allocate block array space of 100 ints
	
	data[100] = 0;
	
	
	return 0;
}
